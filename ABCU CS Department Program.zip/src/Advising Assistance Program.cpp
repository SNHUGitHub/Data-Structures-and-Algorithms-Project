//============================================================================
// Name        : Advising Assistance Program.cpp
// Author      : Quinnie Ho
// Version     : 1.0
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

// Add required libraries
#include <iostream>
#include <fstream>
#include <stack>
#include <vector>

using namespace std;

// Declare structure to hold course information
struct Course {
    string courseID;
    string courseTitle;
    vector<string> coursePrereq;
};

// Declare internal structure for tree node
struct Node {
    Course course;
    Node *left;
    Node *right;

    // Default constructor
    Node() {
        left = nullptr;
        right = nullptr;
    }

    // Initialize with a course
    Node(Course aCourse):
            Node() {
        course = aCourse;
    }
};

// Define class with data members and methods to implement binary search tree
class BinarySearchTree {

private:
    Node* root;

    void addNode(Node* node, Course course);
    void inOrder(Node* node);

public:
    BinarySearchTree();
    virtual ~BinarySearchTree();
    void InOrder();
    void Insert(Course course);
    Course Search(string courseID);
};

// Default constructor
BinarySearchTree::BinarySearchTree() {

    // Initialize root variable
    root = nullptr;
}

// Destructor
BinarySearchTree::~BinarySearchTree() {

    // Declare and initialize an empty stack
    stack<Node*> stack;

    // Assign current node with root
    Node* curr = root;

    // While current node is not empty or size of stack is greater than 0
    while (curr != nullptr || stack.size() > 0) {

        // While current node is not empty
        while (curr != nullptr) {

            // Push the current node to stack
            stack.push(curr);

            // Assign current node to left node
            curr = curr->left;
        }

        // Assign current node to top of stack
        curr = stack.top();

        // Pop top item from stack
        stack.pop();

        // Assign temporary node to current node
        Node* temp = curr;

        // Assign current node to right node
        curr = curr->right;

        // Delete temporary node
        delete temp;
    }
}

// Function to traverse the tree in order
void BinarySearchTree::InOrder() {

    // Call inOrder() and pass root
    inOrder(root);
}

// Function to insert a course
void BinarySearchTree::Insert(Course course) {

	// If root node is empty
	if (root == nullptr) {

		// Assign root to new Node(course)
		root = new Node(course);
	}

	else {

		// Call addNode() function to add course at root level
		this->addNode(root, course);
	}
}

// Function to search for a course
Course BinarySearchTree::Search(string courseID) {

	// Set current node to root
	Node* curr = root;

	// Loop downward until bottom of tree is reached or matching courseID is found
	while (curr != nullptr) {

		// If match found, return current course
		if (curr->course.courseID.compare(courseID) == 0) {
				return curr->course;
		}

		// Traverse left if course is smaller than current node
		else if (courseID.compare(curr->course.courseID) < 0) {
			curr = curr->left;
		}

		// else traverse right
		else {
			curr = curr->right;
		}
	}

	Course course;
	return course;
}

// Function to add a course into the tree
void BinarySearchTree::addNode(Node* node, Course course) {

	// If node is not empty and larger
	if (node != nullptr && node->course.courseID.compare(course.courseID) > 0) {

		// If there is no left node
		if (node->left == nullptr) {

			// Assign new Node(course) to left node
			node->left = new Node(course);

			return;
		}

		else {

			// Recurse down the left node
			this->addNode(node->left, course);
		}
	}

	// Else if node is not empty and smaller
	else if (node != nullptr && node->course.courseID.compare(course.courseID) < 0) {

		// If there is no right node
		if (node->right == nullptr) {

			// Assign new Node(course) to right node
			node->right = new Node(course);

			return;
		}

		else {

			// Recurse down the right node
			this->addNode(node->right, course);
		}
	}
}

void BinarySearchTree::inOrder(Node* node) {

	// If node is not empty
	if (node != nullptr){

		// Call inOrder() and pass in left node
		inOrder(node->left);

		// Print course's number, name, and prerequisite
		cout << node->course.courseID << ", " << node->course.courseTitle << ", " << node->course.coursePrereq << endl;

		// Call inOrder() and pass in right node
		inOrder(node->right);
	}
}

// Function to display course information
void displayCourse(Course course) {
	cout << course.courseID << ", " << course.courseTitle << ", " << endl;
	cout << "Prerequisites: " << course.coursePrereq << endl;
	return;
}

// Function to split content of data file by delimiter
vector<string>tokenize(string name, string delimiter = " ") {

		// Declare vector
		vector<string> stringList;

		// Declare and initialize local variables
		int initialElement = 0;
		int lastElement = name.find(delimiter);

		// Create object of ifstream class to open course information file
		ifstream coursesInfo;

		// Loop while not end of file
		while (!coursesInfo.eof()) {
			stringList.push_back(name.substr(initialElement, lastElement - initialElement));
			initialElement = lastElement + delimiter.size();
			lastElement = name.find(delimiter, initialElement);
		}

		stringList.push_back(name.substr(initialElement, lastElement - initialElement));
		return stringList;
	}

// Function to load and store course info
void loadData(BinarySearchTree* bst) {

	// Create object of ifstream class to open course information file
	ifstream coursesInfo("Course Info.txt", ios::in);

	Course course;

	// Declare local variable
	string line;

	// Loop to print error message if file cannot be opened
	while (!coursesInfo.is_open()) {
		cout << "File cannot be opened. Please check file format and reload." << endl;
	}

	// Loop to read file if file opens successfully
	while (coursesInfo.is_open()) {

		getline(coursesInfo, line);

		// Break loop if end of file is reached
		if (coursesInfo.eof()) {
			break;
		}

		// Get separated info
		vector<string>separatedData = tokenize(line, ",");

		// Storing information in course structure
		course.courseID = separatedData[0];
		course.courseTitle = separatedData[1];

		// Condition to store prerequisites if they exist
		for (int i = 2; i <= separatedData.size(); ++i) {
			course.coursePrereq.push_back(separatedData[i]);
		}

		// Append courses into Course list
		bst->Insert(course);
	}

	// Loop to print error message if end of file is not reached
	while (!coursesInfo.eof()) {
		cout << "Input failure before reaching end of file." << endl;
	}

	// Close file
	coursesInfo.close();

	// Return list of courses
	return;
}

void userMenu() {
	cout << endl;
	cout << "Menu:" << endl;
	cout << "  1. Load Data Structure" << endl;
	cout << "  2. Print Course List" << endl;
	cout << "  3. Print Course" << endl;
	cout << "  4. Exit" << endl;
}

int main(int argc, char* argv) {

	// Declare local variable
	string courseKey;
	int userSelection;

	// Define binary search tree to hold all courses
	BinarySearchTree* bst;
	bst = new BinarySearchTree();
	Course course;

	// Define user menu

	// Print welcome message
	cout << "Welcome to the course planner." << endl;
	cout << "Please enter a number from the menu to continue." << endl;

	// Display user menu
	userMenu();

	// Input user selection
	cin >> userSelection;

	// Loop if user selects unavailable option
	while (!(userSelection <= 1 && userSelection >= 4)) {

		// Print message to notify user of error
		cout << "Invalid selection. Please select a number from the menu to continue." << endl;

		// Call userMenu()
		userMenu();

		// Input user selection
		cin >> userSelection;
	}

	// Loop if user doesn't select exit
	while (userSelection != 4) {

		switch (userSelection) {

		// Call loadData() to load data file
		case 1:
			loadData(bst);

			break;

		// Print course list in alphanumeric order
		case 2:
			cout << "Here is a sample schedule:" << endl;
			cout << endl;

			// Call InOrder()
			bst->InOrder();

			break;

		// Find specific course and print info for that course
		case 3:
			cout << "What course do you want to know about? ";

			// Get user input
			cin >> courseKey;

			// Call Search function and pass in courseKey

			course = bst->Search(courseKey);

			if (!course.courseID.empty()) {
				displayCourse(course);
			}

			else {
				cout << "Course " << courseKey << " was not found." << endl;
			}

			break;
		}
	}

	// Print goodbye message when user selects exit
	cout << "Good bye." << endl;

	return 0;
}
